(function() {
  function buildQuiz() {
    const output = [];
    myQuestions.forEach((currentQuestion, questionNumber) => {
      const answers = [];
      for (letter in currentQuestion.answers) {
        answers.push(
          `<label>
            <input type="radio" name="question${questionNumber}" value="${letter}">
            ${letter} :
            ${currentQuestion.answers[letter]}
          </label>`
        );
      }

      output.push(
        `<div class="question"> ${currentQuestion.question} </div>
        <div class="answers"> ${answers.join("")} </div>`
      );
    });

    quizContainer.innerHTML = output.join("");
  }

  function showResults() {
    const answerContainers = quizContainer.querySelectorAll(".answers");

    let numCorrect = 0;

    myQuestions.forEach((currentQuestion, questionNumber) => {
      const answerContainer = answerContainers[questionNumber];
      const selector = `input[name=question${questionNumber}]:checked`;
      const userAnswer = (answerContainer.querySelector(selector) || {}).value;

      if (userAnswer === currentQuestion.correctAnswer) {
        numCorrect++;
        answerContainers[questionNumber].style.color = "lightgreen";
      } else {
        answerContainers[questionNumber].style.color = "red";
      }
    });

    resultsContainer.innerHTML = `${numCorrect} out of ${myQuestions.length}`;
  }

  const quizContainer = document.getElementById("quiz");
  const resultsContainer = document.getElementById("results");
  const submitButton = document.getElementById("submit");
  const myQuestions = [
    {
      question: "It is a Collection of web resources and applications that is accesed through the Internet.",
      answers: {
        a: "World Wide Web",
        b: "Internet",
        c: "Website"
      },
      correctAnswer: "a"
    },
    {
       question: "Protocol necessary for distributed collaborative hypermedia information system",
      answers: {
        a: "Internet Protocol",
        b: "Hypertext Transfer Protocol",
        c: "Transmission Control Protocol"
      },
      correctAnswer: "b"
    },
    {
      question: " Invented by Sir Timothy Berners-Lee around 1990.",
      answers: {
        a: "Google",
        b: "World Wide Web Consortium",
        c: "World Wide Web"
      },
      correctAnswer: "c"
    },
	{
      question: " HTTP 0.9 started only with _____ method",
      answers: {
        a: "GET",
        b: "HEAD",
        c: "POST"
      },
      correctAnswer: "a"
    },
	{
      question: "URI stands for : ",
      answers: {
        a: "Unified Resource Identifiers",
        b: "Uniform Resource Identifiers",
        c: "Uniform Resource Identification"
      },
      correctAnswer: "b"
    },
	{
      question: "HTTP Request has the Request Line while HTTP Response has?",
      answers: {
        a: "Response Line",
        b: "Empty line",
        c: "Status Line"
      },
      correctAnswer: "c"
    },
	{
      question: "On HTTP Request Message, this method obtains the target resource",
      answers: {
        a: "POST",
        b: "PUT",
        c: "GET"
      },
      correctAnswer: "c"
    },
	{
      question: "On HTTP Request Message, this method establishes a tunnel to the server (end-to-end virtual connecting)",
      answers: {
        a: "OPTIONS",
        b: "CONNECT",
        c: "GET"
      },
      correctAnswer: "b"
    },
	{
      question: "On HTTP Request Message, this method determine requirements/capabilities of serves to the target resource.",
      answers: {
        a: "OPTIONS",
        b: "TRACE",
        c: "GET"
      },
      correctAnswer: "a"
    },
	{
      question: "On HTTP Request Message, this method loops back (echo/repeats request).",
      answers: {
        a: "OPTIONS",
        b: "TRACE",
        c: "POST"
      },
      correctAnswer: "b"
    },
	{
      question: "On HTTP Request Message, this method removes the resource permanently",
      answers: {
        a: "OPTIONS",
        b: "HEAD",
        c: "DELETE"
      },
      correctAnswer: "c"
    },
	{
      question: "On HTTP Request Message, this method creates/replaces target resource.",
      answers: {
        a: "OPTION",
        b: "PUT",
        c: "GET"
      },
      correctAnswer: "b"
    },
	{
      question: "On HTTP Request Message, this method is used to obtain metadata about the target resource without having the body.",
      answers: {
        a: "HEAD",
        b: "TRACE",
        c: "GET"
      },
      correctAnswer: "a"
    },
	{
      question: "On HTTP Request Message, this method processes on origin metadata about the target resource without having data.",
      answers: {
        a: "HEAD",
        b: "POST",
        c: "GET"
      },
      correctAnswer: "b"
    },
	{
      question: "These properties are Safe - read-only method, no changes in the server.Except for one",
      answers: {
        a: "GET",
        b: "HEAD",
        c: "PUT"
      },
      correctAnswer: "c"
    },
	{
      question: "These properties are Idempotent - no matter how many times the request is made, the expected behavior from the server is the same.Except for one",
      answers: {
        a: "HEAD",
        b: "POST",
        c: "GET"
      },
      correctAnswer: "b"
    },
	{
      question: "A property that is Cacheable - the response for a method is allowed to be for future use.",
      answers: {
        a: "OPTION",
        b: "POST",
        c: "TRACE"
      },
      correctAnswer: "b"
    },
	{
      question: "On HTTP Request Message, this method processes on origin metadata about the target resource without having data.",
      answers: {
        a: "HEAD",
        b: "PUT",
        c: "GET"
      },
      correctAnswer: "b"
    },
	{
      question: "Language used to markup documents (i.e. Web Pages).",
      answers: {
        a: "Hypertext Transfer Protocol",
        b: "Hypertext Marking Language",
        c: "Hypertext Markup Language"
      },
      correctAnswer: "c"
    },
	{
      question: "HTML was initally developed at CERN, IETF then W3C and _____",
      answers: {
        a: "WHATWG",
        b: "RFC",
        c: "W3CWHAT"
      },
      correctAnswer: "a"
    },
	{
      question: "It mirrors or extends versions of the widely used Hypertext Markup Language",
      answers: {
        a: "HTTPS",
        b: "Extensible Hypertext Markup Language",
        c: "HTTP"
      },
      correctAnswer: "b"
    },
	{
      question: "In HTML 5 WAI -ARIA stands for: ",
      answers: {
        a: "Website Accessibility Interconnection – Accessible Rich Internet Applications",
        b: "Web Accessibility Initiative – Accessible Rich Internet Applications",
        c: "Web Accesible Initiative – Accessible Rich Internet Applicators"
      },
      correctAnswer: "b"
    },
	{
      question: "New syntactic features are included in HTML 5 like____ and ____ ",
      answers: {
        a: "Header, Footer",
        b: "SVG, MathML",
        c: "Article, Section"
      },
      correctAnswer: "b"
    }
  ];

  
  buildQuiz();

  // on submit, show results
  submitButton.addEventListener("click", showResults);
})();

var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
}