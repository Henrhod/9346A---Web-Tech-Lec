<?php 
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$dbname = 'test';

	$conn = mysqli_connect($host,$user,$pass,$dbname);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Quizzes - Multiple Choice</title>
	<link rel="stylesheet" type="text/css" href="Style/style.css">
	<link rel="icon" href="Images/K.png">
</head>
<body>
	<div id="wrapper">
		<header id="header">
			<div id="header_logo">
				<img src="Images/K.png" width="150" height="150" alt="Logo">
			</div>
			<div id="header_title">
				<div class="title">Web Systems and Technologies</div> <br>
				<div class="subtitle">Finals Topics</div>
			</div>
		</header>
		<div class="navbar">
  			<a href="index.html">Java Servlets</a>
  			<a href="JavaServerPages.html">Java Server Pages</a>
  			<a href="PHP.html">PHP</a>
  			<a href="Node.html">Node JS</a>
  			<a href="OWASP.html">OWASP</a>
  			<a href="References.html">Read More</a>
  			<div class="dropdown">
    			<button class="dropbtn">Quizzes</button>
    			<div class="dropdown-content">
		      		<a href="Crossword.html">Crossword Puzzle</a>
		      		<a href="quiz.php">Multiple Choice</a>
    			</div>
  			</div>
  			<div class="search"> 
	  			<form>
	  				<label for="search">Search: </label>
					<input class="Searchinput" type="text" onkeyup="showResult(this.value)" placeholder="Topic">
					<div id="livesearch"></div>
				</form>
			</div>
		</div> 
		<div id="content">
			<p> </p>
			<p> </p>
			<a id="1"><div class="content1">Multiple Choice Quiz</div></a>
			<br>
			<div class="content2">
				<form method="post" action="result.php">
				<?php
				$sql = "Select * from quiz;";
				$result = mysqli_query($conn,$sql);
				$count = mysqli_num_rows($result);
				if($count>0){
					while($row = mysqli_fetch_assoc($result)){
						$choices = array($row['choice1'], $row['choice2'], $row['answer']);
						shuffle($choices);
						echo "<p>".$row['quizID'] . ". ".$row['question'] . "</p>";
						echo "<input type=\"radio\" name=\"quizid".$row['quizID']."\"value=\"".$choices[0]."\"required>".$choices[0]."<br>";
						echo "<input type=\"radio\" name=\"quizid".$row['quizID']."\"value=\"".$choices[1]."\"required>".$choices[1]."<br>";
						echo "<input type=\"radio\" name=\"quizid".$row['quizID']."\"value=\"".$choices[2]."\"required>".$choices[2]."<br><br><hr>";
					}
				}
				?>
				<center><input type="submit" name="submit" value="Submit" id="show"></input></center>
			    </form>
	 		</div>					
	 	</div>				
	</div>
	<script type="text/javascript" src="script.js"></script>
</body>
</html>