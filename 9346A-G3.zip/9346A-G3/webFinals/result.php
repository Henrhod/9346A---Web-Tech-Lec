<!--
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Webtech Lec Quiz</title>

</head>
<body>
	Results<br>
	<form method="post" action="quiz.php">

<?php
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$dbname = 'test';

	$conn = mysqli_connect($host,$user,$pass,$dbname);

	
	$sql = "Select * from quiz;";
	$result = mysqli_query($conn,$sql);
	$count = mysqli_num_rows($result);
	$score = 0;
	if($count>0){
		$x = 1;
		while($row = mysqli_fetch_assoc($result)){
			echo "<p>".$row['quizID'] . ". ".$row['question'] . "</p>";
			echo "You have selected :".$_POST['quizid'.$x]."<br>";
			if($_POST['quizid'.$x]==$row['answer']){
				echo "<p><span style=\"background-color: #ADFFB4\">Correct</span></p>";
				$score = $score + 1;
			}else{
				echo "<p><span style=\"background-color: #FF9C9E\">Wrong. The correct answer is: ".$row['answer']."</span></p>";
			}
			$x = $x+1;
			}
	}
	?>
	
	<br>
	<p>Score: <?php echo $score?>/15</p>
	<input type="submit" name="submit" value="Play Again" id="show">
    </form>
	
</body>
 
</html>
-->

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>JavaServer Pages</title>
	<link rel="stylesheet" type="text/css" href="Style/style.css">
	<link rel="icon" href="Images/K.png">
</head>
<body>
	<div id="wrapper">
		<header id="header">
			<div id="header_logo">
				<img src="Images/K.png" width="150" height="150" alt="Logo">
			</div>
			<div id="header_title">
				<div class="title">Web Systems and Technologies</div> <br>
				<div class="subtitle">Finals Topics</div>
			</div>
		</header>
		<div class="navbar">
  			<a href="index.html">Java Servlets</a>
  			<a href="JavaServerPages.html">Java Server Pages</a>
  			<a href="PHP.html">PHP</a>
  			<a href="Node.html">Node JS</a>
  			<a href="OWASP.html">OWASP</a>
  			<a href="References.html">Read More</a>
  			<div class="dropdown">
    			<button class="dropbtn">Quizzes</button>
    			<div class="dropdown-content">
		      		<a href="Crossword.html">Crossword Puzzle</a>
		      		<a href="quiz.php">Multiple Choice</a>
    			</div>
  			</div>
  			<div class="search"> 
	  			<form>
	  				<label for="search">Search: </label>
					<input class="Searchinput" type="text" onkeyup="showResult(this.value)" placeholder="Topic">
					<div id="livesearch"></div>
				</form>
			</div>
		</div> 
		<div id="content">
			<p> </p>
			<p> </p>
			<a id="1"><div class="content1">Multiple Choice Quiz</div></a>
			<br>
			<div class="content2">
				<form method="post" action="quiz.php">
				<?php
					$host = 'localhost';
					$user = 'root';
					$pass = '';
					$dbname = 'test';

					$conn = mysqli_connect($host,$user,$pass,$dbname);
		
					$sql = "Select * from quiz;";
					$result = mysqli_query($conn,$sql);
					$count = mysqli_num_rows($result);
					$score = 0;
					if($count>0){
						$x = 1;
						while($row = mysqli_fetch_assoc($result)){
							echo "<p>".$row['quizID'] . ". ".$row['question'] . "</p>";
							echo "<p> You have selected: ".$_POST['quizid'.$x]."</p>";
							if($_POST['quizid'.$x]==$row['answer']){
								echo "<p><span style=\"background-color: #ADFFB4\">Correct</span></p><hr>";
								$score = $score + 1;
							}else{
								echo "<p><span style=\"background-color: #FF9C9E\">Wrong (The correct answer is: ".$row['answer'].")</span></p><hr>";
							}
							$x = $x+1;
						}
					}
					?>	
					<br>
					<center>Score: <?php echo $score?>/15</center>
					<br>
					<center><input type="submit" name="submit" value="Play Again" id="show"></center>
				</form>
	 		</div>					
	 	</div>				
	</div>
	<script type="text/javascript" src="script.js"></script>
</body>
</html>
