The Website is hosted in the WampServer using the folder 'webFinals' 

and the 'test.sql' must be imported in the localhost database in order
for the quiz to function.

To access the website go to:localhost/webFinals